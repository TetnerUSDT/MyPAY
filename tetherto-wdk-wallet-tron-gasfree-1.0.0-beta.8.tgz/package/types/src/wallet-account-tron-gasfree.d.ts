/** @implements {IWalletAccount} */
export default class WalletAccountTronGasfree extends WalletAccountReadOnlyTronGasfree implements IWalletAccount {
    /**
     * Creates a new tron gasfree wallet account.
     *
     * @param {string | Uint8Array} seed - The wallet's [BIP-39](https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki) seed phrase.
     * @param {string} path - The BIP-44 derivation path (e.g. "0'/0/0").
     * @param {TronGasfreeWalletConfig} config - The configuration object.
     */
    constructor(seed: string | Uint8Array, path: string, config: TronGasfreeWalletConfig);
    /**
     * The tron gasfree wallet account configuration.
     *
     * @protected
     * @type {TronGasfreeWalletConfig}
     */
    protected _config: TronGasfreeWalletConfig;
    /** @private */
    private _ownerAccount;
    /**
     * The derivation path's index of this account.
     *
     * @type {number}
     */
    get index(): number;
    /**
     * The derivation path of this account (see [BIP-44](https://github.com/bitcoin/bips/blob/master/bip-0044.mediawiki)).
     *
     * @type {string}
     */
    get path(): string;
    /**
     * The account's key pair.
     *
     * The uint8 arrays are bound to the wallet account, so any external change will reflect to the internal representation. For this reason,
     * it's strongly recommended to treat the key pair as a read-only view of the keys. While it's still technically possible to alter their
     * content, client code should never do so.
     *
     * @type {KeyPair}
     */
    get keyPair(): KeyPair;
    /**
     * Signs a message.
     *
     * @param {string} message - The message to sign.
     * @returns {Promise<string>} The message's signature.
     */
    sign(message: string): Promise<string>;
    /**
     * Signs a transaction.
     *
     * @param {TronTransaction} tx - The transaction.
     * @returns {Promise<never>} Never resolves; always throws.
     */
    signTransaction(tx: TronTransaction): Promise<never>;
    /**
     * Sends a transaction.
     *
     * @param {TronTransaction} tx - The transaction.
     * @returns {Promise<TransactionResult>} The transaction's result.
     */
    sendTransaction(tx: TronTransaction): Promise<TransactionResult>;
    /**
     * Transfers a token to another address, paying gas fees with the transferred token.
     *
     * @param {TransferOptions} options - The transfer's options.
     * @param {Object} [config] - A configuration object containing additional options.
     * @param {number | bigint} [config.transferMaxFee] - The maximum fee amount for the transfer operation.
     * @returns {Promise<TransferResult & TronActivationFee>} The transfer's result.
     * @throws {Error} If the transfer's cost exceeds the maximum transfer fee option.
     */
    transfer({ token, recipient, amount }: TransferOptions, config?: {
        transferMaxFee?: number | bigint;
    }): Promise<TransferResult & TronActivationFee>;
    /**
     * Returns a read-only copy of the account.
     *
     * @returns {Promise<WalletAccountReadOnlyTronGasfree>} The read-only account.
     */
    toReadOnlyAccount(): Promise<WalletAccountReadOnlyTronGasfree>;
    /**
     * Disposes the wallet account, erasing the private key from the memory.
     */
    dispose(): void;
    /** @private */
    private _signTypedData;
}
export type IWalletAccount = import("@tetherto/wdk-wallet").IWalletAccount;
export type KeyPair = import("@tetherto/wdk-wallet-tron").KeyPair;
export type TronTransaction = import("@tetherto/wdk-wallet-tron").TronTransaction;
export type TransactionResult = import("@tetherto/wdk-wallet-tron").TransactionResult;
export type TransferOptions = import("@tetherto/wdk-wallet-tron").TransferOptions;
export type TransferResult = import("@tetherto/wdk-wallet-tron").TransferResult;
export type TronActivationFee = import("@tetherto/wdk-wallet-tron").TronActivationFee;
export type TronTransactionReceipt = import("@tetherto/wdk-wallet-tron").TronTransactionReceipt;
export type TronGasfreeWalletConfig = import("./wallet-account-read-only-tron-gasfree.js").TronGasfreeWalletConfig;
import WalletAccountReadOnlyTronGasfree from './wallet-account-read-only-tron-gasfree.js';
