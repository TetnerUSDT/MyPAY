import { useState, useEffect, useRef } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { Clock, ArrowDown, Copy, Check, Loader2, CheckCircle2, XCircle, X } from "lucide-react";
import { UnifiedPreloader } from "@/components/UnifiedPreloader";
import { formatCountdown, copyToClipboard, formatOrderAmount, formatRecipientAddress, getRecipientLabelKey } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useNotificationStream } from "@/hooks/use-notification-stream";
import { useTranslation } from "react-i18next";

interface ExchangeOrder {
  id: number;
  numberOrder: string;
  idUser: number;
  walletId: number;
  idBalanceFrom: number;
  idBalanceTo: number;
  idCard: number | null;
  fromCurrency: string;
  toCurrency: string;
  amountFrom: string;
  amountTo: string;
  rate: string;
  commission: string;
  timestamp: string;
  status: 'wait' | 'wait-paid' | 'paid' | 'complete' | 'canceled' | 'dispute';
  walletAddress?: string;
  walletNetwork?: string;
  cardNumber?: string;
  timeExchange?: number;
  cancelReason?: string;
  paymentHash?: string;
}

export default function TrackingScreen() {
  const { t } = useTranslation();
  const searchParams = new URLSearchParams(useSearch());
  const orderNumber = searchParams.get('order');
  const [countdown, setCountdown] = useState(3600); // 1 hour default
  const [copied, setCopied] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const confettiRef = useRef<HTMLCanvasElement>(null);

  // Load exchange order data with polling every 30 seconds
  const { data: orderData, isLoading } = useQuery<ExchangeOrder>({
    queryKey: ['/api/exchange', orderNumber],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/exchange/${orderNumber}`, undefined);
      return response.json();
    },
    enabled: !!orderNumber,
    refetchInterval: 60000, // Poll every 60 seconds (SSE pushes real-time updates anyway)
    refetchOnWindowFocus: true, // Refetch when user returns to window
    staleTime: 0, // Always consider data stale to allow refetching
    gcTime: 0, // Don't cache the data
  });

  // Subscribe to real-time exchange updates via SSE
  useNotificationStream({
    onExchangeUpdate: (exchange) => {
      console.log('[Tracking] Exchange update received:', exchange);
      // The query will automatically refetch due to cache invalidation in the hook
    }
  });

  // Update countdown based on timeExchange when orderData is available
  useEffect(() => {
    if (orderData?.timeExchange) {
      setCountdown(orderData.timeExchange * 60); // Convert minutes to seconds
    }
  }, [orderData?.timeExchange]);

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Redirect if no order number
  useEffect(() => {
    if (!orderNumber) {
      setLocation("/wallet");
    }
  }, [orderNumber, setLocation]);

  const handleCopyTxHash = async () => {
    const txHash = orderData?.paymentHash || "";
    try {
      await copyToClipboard(txHash);
      setCopied(true);
      toast({
        title: t('common.copied'),
        description: t('tracking.hashCopied'),
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: t('common.copyError'),
        variant: "destructive",
      });
    }
  };

  const handleBackToHome = () => {
    setLocation("/home");
  };


  // Confetti animation for success state
  useEffect(() => {
    if (orderData?.status === "complete" && confettiRef.current) {
      const canvas = confettiRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;

      const particles: Array<{
        x: number;
        y: number;
        vx: number;
        vy: number;
        color: string;
        size: number;
        rotation: number;
        rotationSpeed: number;
      }> = [];

      const colors = ['#a5fe7c', '#ffeb3b', '#ff5722', '#2196f3', '#e91e63', '#00bcd4'];

      // Create particles
      for (let i = 0; i < 100; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: -10,
          vx: (Math.random() - 0.5) * 4,
          vy: Math.random() * 3 + 2,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 6 + 2,
          rotation: Math.random() * 360,
          rotationSpeed: (Math.random() - 0.5) * 10
        });
      }

      let animationId: number;

      const animate = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach((particle, index) => {
          particle.x += particle.vx;
          particle.y += particle.vy;
          particle.vy += 0.1; // gravity
          particle.rotation += particle.rotationSpeed;

          ctx.save();
          ctx.translate(particle.x, particle.y);
          ctx.rotate((particle.rotation * Math.PI) / 180);
          ctx.fillStyle = particle.color;
          ctx.fillRect(-particle.size / 2, -particle.size / 2, particle.size, particle.size);
          ctx.restore();

          // Remove particles that are off screen
          if (particle.y > canvas.height + 10) {
            particles.splice(index, 1);
          }
        });

        if (particles.length > 0) {
          animationId = requestAnimationFrame(animate);
        }
      };

      animate();

      return () => {
        if (animationId) {
          cancelAnimationFrame(animationId);
        }
      };
    }
  }, [orderData?.status]);

  // Show loading state
  if (isLoading || !orderData) {
    return <UnifiedPreloader label={t('common.loading')} />;
  }

  // State 1: Waiting for payment (wait)
  if (orderData.status === "wait") {
    return (
      <div className="mobile-screen text-white relative overflow-hidden">
        {/* Close button */}
        <div className="absolute top-6 right-6 z-30">
          <Link href="/home">
            <button 
              className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 transition-colors"
              data-testid="button-close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </Link>
        </div>
        
        <div className="flex flex-col items-center justify-center min-h-screen text-center px-6">
          <h1 className="text-2xl font-bold mb-4" data-testid="text-title">
            {t('tracking.waitingPayment')}
          </h1>
          
          <div className="text-xl text-yellow-400 font-semibold mb-8" data-testid="text-status">
            {t('tracking.awaitingPayment')}
          </div>
          
          {/* Timer */}
          <div className="inline-flex items-center bg-secondary border border-yellow-400 rounded-lg px-4 py-2 mb-16">
            <Clock className="w-6 h-6 mr-2 text-yellow-400" />
            <span className="font-mono text-lg text-yellow-400" data-testid="text-countdown">
              {formatCountdown(countdown)}
            </span>
          </div>

          {/* Waiting Animation */}
          <div className="w-full max-w-md crypto-card flex items-center justify-center p-8">
            <Loader2 
              className="w-40 h-40 text-accent animate-spin"
              data-testid="animation-waiting"
            />
          </div>
        </div>
      </div>
    );
  }

  // State 2: Waiting for transaction confirmation (wait-paid)
  if (orderData.status === "wait-paid") {
    return (
      <div className="mobile-screen text-white relative overflow-hidden">
        {/* Close button */}
        <div className="absolute top-6 right-6 z-30">
          <Link href="/home">
            <button 
              className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 transition-colors"
              data-testid="button-close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </Link>
        </div>
        
        <div className="flex flex-col items-center justify-center min-h-screen text-center px-6">
          <h1 className="text-2xl font-bold mb-4" data-testid="text-title">
            {t('tracking.verifyingPayment')}
          </h1>
          
          <div className="text-xl text-yellow-400 font-semibold mb-8" data-testid="text-status">
            {t('tracking.searchingTransaction')}
          </div>
          
          {/* Timer */}
          <div className="inline-flex items-center bg-secondary border border-yellow-400 rounded-lg px-4 py-2 mb-16">
            <Clock className="w-6 h-6 mr-2 text-yellow-400" />
            <span className="font-mono text-lg text-yellow-400" data-testid="text-countdown">
              {formatCountdown(countdown)}
            </span>
          </div>

          {/* Payment Processing Animation */}
          <div className="w-full max-w-md crypto-card flex items-center justify-center p-8">
            <Loader2 
              className="w-40 h-40 text-accent animate-spin"
              data-testid="animation-payment-processing"
            />
          </div>
        </div>
      </div>
    );
  }

  // State 2: Processing application (paid)
  if (orderData.status === "paid") {
    return (
      <div className="mobile-screen text-white relative">
        {/* Close button */}
        <div className="absolute top-6 right-6 z-30">
          <Link href="/home">
            <button 
              className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 transition-colors"
              data-testid="button-close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </Link>
        </div>
        
        <div className="flex flex-col items-center justify-center min-h-screen text-center px-6">
          <h1 className="text-2xl font-bold mb-4" data-testid="text-title">
            {t('tracking.processingOrder')}
          </h1>
          
          <div className="text-2xl text-yellow-400 font-bold mb-4" data-testid="text-application-number">
            {orderData.numberOrder}
          </div>
          
          {/* Timer */}
          <div className="inline-flex items-center bg-secondary border border-yellow-400 rounded-lg px-4 py-2 mb-8">
            <Clock className="w-6 h-6 mr-2 text-yellow-400" />
            <span className="font-mono text-lg text-yellow-400" data-testid="text-countdown">
              {formatCountdown(countdown)}
            </span>
          </div>

          {/* Transaction Found */}
          <div className="w-full max-w-md crypto-card mb-4">
            <div className="text-sm text-muted-foreground mb-2 text-left">{t('tracking.hashFound')}</div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-3xl font-bold">{formatOrderAmount(orderData.amountFrom)}</span>
              <span className="text-lg font-semibold text-yellow-400">{orderData.fromCurrency}</span>
            </div>
            
            <div className="bg-secondary rounded-lg p-3 mb-2 relative">
              <div className="font-mono text-xs break-all text-left" data-testid="text-transaction-hash">
                {orderData.paymentHash || t('tracking.waitingHash')}
              </div>
              <button 
                className="absolute top-2 right-2 p-1 hover:bg-white/10 rounded"
                onClick={handleCopyTxHash}
                data-testid="button-copy-hash"
              >
                {copied ? (
                  <Check className="w-6 h-6 text-green-400" />
                ) : (
                  <Copy className="w-6 h-6 text-accent" />
                )}
              </button>
            </div>
          </div>

          {/* Arrow Down */}
          <div className="flex justify-center" style={{position: 'relative', marginTop: '-20px', marginBottom: '-30px', zIndex: 2}}>
            <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center border-[6px]" style={{borderColor: '#2a4c3b', top: '-10px', position: 'relative'}}>
              <ArrowDown className="w-6 h-6 text-accent-foreground" />
            </div>
          </div>

          {/* Ready to Send */}
          <div className="w-full max-w-md crypto-card mb-8">
            <div className="text-sm text-muted-foreground mb-2 text-left">{t('tracking.preparingToSend')}</div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-3xl font-bold">{formatOrderAmount(orderData.amountTo)}</span>
              <span className="text-lg font-semibold text-yellow-400">{orderData.toCurrency}</span>
            </div>
            
            <div className="text-sm text-muted-foreground mb-2 text-left">{t(getRecipientLabelKey(orderData.cardNumber || ''))}</div>
            <div className="bg-secondary rounded-lg p-3">
              <span className="font-mono" data-testid="text-card-number">
                {formatRecipientAddress(orderData.cardNumber || '') || t('common.loading')}
              </span>
            </div>
          </div>

          {/* Processing Animation Small */}
          <div className="w-12 h-12 crypto-card flex items-center justify-center p-1 mb-8">
            <Loader2 
              className="w-8 h-8 text-accent animate-spin"
              data-testid="animation-hourglass-small"
            />
          </div>

          {/* Support Block */}
          <div className="w-full max-w-md crypto-card text-left">
            <h3 className="text-lg font-semibold text-white mb-4">
              {t('tracking.supportTitle')}
            </h3>
            
            <p className="text-sm text-muted-foreground mb-3">
              {t('tracking.supportDesc')}
            </p>
            
            <p className="text-sm text-white mb-1">{t('tracking.weCanHelp')}:</p>
            <ul className="text-sm text-muted-foreground mb-4 space-y-1">
              <li>• {t('tracking.checkDealStatus')}</li>
              <li>• {t('tracking.clarifyPaymentDetails')}</li>
              <li>• {t('tracking.resolveTransaction')}</li>
              <li>• {t('tracking.solveTechnicalIssues')}</li>
            </ul>
            
            <p className="text-sm text-muted-foreground mb-3">
              {t('tracking.contactUs')}
            </p>
            
            <a 
              href="https://t.me/SwiftX11" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center text-accent hover:text-accent/80 transition-colors font-medium"
              data-testid="link-support"
            >
              👉 @SwiftX11
            </a>
          </div>
        </div>
      </div>
    );
  }

  // State 3: Success (complete)
  if (orderData.status === "complete") {
    return (
      <div className="mobile-screen text-white relative">
        {/* Confetti Canvas */}
        <canvas
          ref={confettiRef}
          className="absolute inset-0 pointer-events-none z-10"
          style={{ position: 'fixed', top: 0, left: 0 }}
        />
        
        {/* Close button */}
        <div className="absolute top-6 right-6 z-30">
          <Link href="/home">
            <button 
              className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 transition-colors"
              data-testid="button-close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </Link>
        </div>
        
        <div className="flex flex-col items-center justify-center min-h-screen text-center px-6 relative z-20">
          <h1 className="text-2xl font-bold mb-12" data-testid="text-title">
            {t('tracking.successComplete')}
          </h1>
          
          {/* Success Animation */}
          <div className="w-32 h-32 mb-12 flex items-center justify-center">
            <CheckCircle2 
              className="w-32 h-32 text-accent"
              data-testid="animation-success"
            />
          </div>
          
          <p className="text-lg mb-16 px-4">
            {t('tracking.exchangeCompleted')}
          </p>
          
          <div className="w-full max-w-sm mb-8">
            <Link href="/support">
              <p className="text-sm text-yellow-400 text-center cursor-pointer hover:underline" data-testid="link-support">
                {t('tracking.notReceivedFunds')}
              </p>
            </Link>
          </div>
          
          <div className="w-full max-w-sm">
            <button 
              className="action-button"
              onClick={handleBackToHome}
              data-testid="button-back-home"
            >
              {t('common.backToHome')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // State 4: Canceled
  if (orderData.status === "canceled") {
    return (
      <div className="mobile-screen text-white relative">
        {/* Close button */}
        <div className="absolute top-6 right-6 z-30">
          <Link href="/home">
            <button 
              className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 transition-colors"
              data-testid="button-close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </Link>
        </div>
        
        <div className="flex flex-col items-center justify-center min-h-screen text-center px-6 relative z-20">
          <h1 className="text-2xl font-bold mb-12" data-testid="text-title">
            {t('tracking.paymentCanceled')}
          </h1>
          
          {/* Cancel Icon */}
          <div className="w-32 h-32 mb-12 flex items-center justify-center">
            <XCircle 
              className="w-32 h-32 text-red-500"
              data-testid="animation-canceled"
            />
          </div>
          
          <p className="text-lg mb-8 px-4">
            {t('tracking.exchangeCanceled')}
          </p>

          {orderData.cancelReason && (
            <div className="w-full max-w-md mb-12 crypto-card">
              <div className="text-sm text-muted-foreground mb-2">{t('tracking.cancelReason')}</div>
              <p className="text-base">{orderData.cancelReason}</p>
            </div>
          )}
          
          <div className="w-full max-w-sm mb-8">
            <Link href="/support">
              <p className="text-sm text-yellow-400 text-center cursor-pointer hover:underline" data-testid="link-support">
                {t('tracking.contactSupport')}
              </p>
            </Link>
          </div>
          
          <div className="w-full max-w-sm">
            <button 
              className="action-button"
              onClick={handleBackToHome}
              data-testid="button-back-home"
            >
              {t('common.backToHome')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // State 5: Dispute
  if (orderData.status === "dispute") {
    return (
      <div className="mobile-screen text-white relative">
        {/* Close button */}
        <div className="absolute top-6 right-6 z-30">
          <Link href="/home">
            <button 
              className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center hover:bg-black/30 transition-colors"
              data-testid="button-close"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </Link>
        </div>
        
        <div className="flex flex-col items-center justify-center min-h-screen text-center px-6 relative z-20">
          <h1 className="text-2xl font-bold mb-12" data-testid="text-title">
            {t('tracking.disputeOpened')}
          </h1>
          
          <div className="w-32 h-32 mb-12 flex items-center justify-center">
            <XCircle 
              className="w-32 h-32 text-yellow-400"
              data-testid="animation-dispute"
            />
          </div>
          
          <p className="text-lg mb-16 px-4">
            {t('tracking.disputeMessage')}
          </p>
          
          <div className="w-full max-w-sm mb-8">
            <Link href="/support">
              <button className="action-button" data-testid="button-contact-support">
                {t('tracking.contactSupport')}
              </button>
            </Link>
          </div>
          
          <div className="w-full max-w-sm">
            <button 
              className="w-full py-3 bg-secondary hover:bg-secondary/80 text-white rounded-lg transition-colors"
              onClick={handleBackToHome}
              data-testid="button-back-home"
            >
              {t('common.backToHome')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Default fallback
  return (
    <div className="mobile-screen text-white flex items-center justify-center">
      <div className="text-center">
        <div className="text-lg">{t('tracking.pending')}</div>
      </div>
    </div>
  );
}
